﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtbxRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtbxRaio.Focus();

            }
            else if (raio<=0)
            {
                MessageBox.Show("Raio não pode ser <=0");
                txtbxRaio.Focus();
            }
        }

        private void TxtbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                txtbxAltura.Focus();
            }
            else if (altura <= 0)
            {
                MessageBox.Show("A altura não pode ser <=0");
                txtbxAltura.Focus();
            }
        }

            private void btnFechar_Click(object sender, EventArgs e)
            {
                Close();
            }

        private void txtbxRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtbxAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void BtnCalculo_Click(object sender, EventArgs e)
        {
            double volume;
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtbxVolume.Text = volume.ToString("N2");
        }
    }
}

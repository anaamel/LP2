﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salarioBruto, salarioLiq, salarioFamilia, desconto1, desconto2;
        public Form1()
        {
            InitializeComponent();
        }
        private void mskdbxSalBruto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtbxNome_Validated(object sender, EventArgs e)
        {
            if (txtbxNome.Text.Length < 10)
            {
                MessageBox.Show("Nome deve ter mais de 10 caracteres");
                txtbxNome.Focus();
            }
        }
        private void txtbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
            }
            else if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void NumUpFilhos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        private void btnVerifica_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskdbxSalBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Favor entrar com valor válido");
            }
            else if (salarioBruto <= 0)
            {
                MessageBox.Show("Salário não pode ser menor ou igual a zero");
            }
            else
            {
                if (salarioBruto <= 800.47)
                {
                    txtbxAliq1.Text = "7,65%";
                    desconto1 = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtbxAliq1.Text = " 8,65%";
                    desconto1 = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtbxAliq1.Text = "9,00%";
                    desconto1 = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtbxAliq1.Text = "11,00%";
                    desconto1 = 0.11 * salarioBruto;
                }
                else
                {
                    txtbxAliq1.Text = "Teto";
                    desconto1 = 308.17;
                }
                txtbxDesc1.Text = desconto1.ToString("N2");


                if (salarioBruto < 1257.13)
                {
                    txtbxAliq2.Text = "Isento";
                    desconto2 = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtbxAliq2.Text = "15,00%";
                    desconto2 = 0.15 * salarioBruto;
                }
                else
                {
                    txtbxAliq2.Text = "27,50%";
                    desconto2 = 0.275 * salarioBruto;
                }
                txtbxDesc2.Text = desconto2.ToString("N2");

                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = ((int)NumUpFilhos.Value) * 22.33;
                    txtbxSalFamilia.Text = salarioFamilia.ToString("N2");
                }
                else if (salarioBruto <= 654.61)
                {
                    salarioFamilia = ((int)NumUpFilhos.Value) * 15.74;
                    txtbxSalFamilia.Text = salarioFamilia.ToString("N2");
                }
                else
                {
                    salarioFamilia = 0;
                    txtbxSalFamilia.Text = salarioFamilia.ToString("N2");
                }

                salarioLiq = salarioBruto - desconto1 - desconto2 + salarioFamilia;
                txtbxSalLiq.Text = salarioLiq.ToString("N2");

            }
        }
    }
}

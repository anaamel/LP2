﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.txtbxNome = new System.Windows.Forms.TextBox();
            this.mskdbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblAliq1 = new System.Windows.Forms.Label();
            this.lblAliq2 = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDesc1 = new System.Windows.Forms.Label();
            this.lblDesc2 = new System.Windows.Forms.Label();
            this.txtbxDesc1 = new System.Windows.Forms.TextBox();
            this.txtbxAliq1 = new System.Windows.Forms.TextBox();
            this.txtbxDesc2 = new System.Windows.Forms.TextBox();
            this.txtbxAliq2 = new System.Windows.Forms.TextBox();
            this.txtbxSalFamilia = new System.Windows.Forms.TextBox();
            this.txtbxSalLiq = new System.Windows.Forms.TextBox();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.NumUpFilhos = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(82, 72);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(90, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(81, 146);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(66, 13);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(81, 213);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // txtbxNome
            // 
            this.txtbxNome.Location = new System.Drawing.Point(203, 64);
            this.txtbxNome.Name = "txtbxNome";
            this.txtbxNome.Size = new System.Drawing.Size(421, 20);
            this.txtbxNome.TabIndex = 3;
            this.txtbxNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxNome_KeyPress);
            this.txtbxNome.Validated += new System.EventHandler(this.txtbxNome_Validated);
            // 
            // mskdbxSalBruto
            // 
            this.mskdbxSalBruto.Location = new System.Drawing.Point(202, 139);
            this.mskdbxSalBruto.Mask = "0000000,00";
            this.mskdbxSalBruto.Name = "mskdbxSalBruto";
            this.mskdbxSalBruto.Size = new System.Drawing.Size(80, 20);
            this.mskdbxSalBruto.TabIndex = 7;
            this.mskdbxSalBruto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskdbxSalBruto_KeyPress);
            // 
            // lblAliq1
            // 
            this.lblAliq1.AutoSize = true;
            this.lblAliq1.Location = new System.Drawing.Point(87, 348);
            this.lblAliq1.Name = "lblAliq1";
            this.lblAliq1.Size = new System.Drawing.Size(73, 13);
            this.lblAliq1.TabIndex = 8;
            this.lblAliq1.Text = "Aliquota INSS";
            // 
            // lblAliq2
            // 
            this.lblAliq2.AutoSize = true;
            this.lblAliq2.Location = new System.Drawing.Point(88, 384);
            this.lblAliq2.Name = "lblAliq2";
            this.lblAliq2.Size = new System.Drawing.Size(72, 13);
            this.lblAliq2.TabIndex = 9;
            this.lblAliq2.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(88, 423);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 10;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(87, 463);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(74, 13);
            this.lblSalLiq.TabIndex = 11;
            this.lblSalLiq.Text = "Salário líquido";
            // 
            // lblDesc1
            // 
            this.lblDesc1.AutoSize = true;
            this.lblDesc1.Location = new System.Drawing.Point(421, 348);
            this.lblDesc1.Name = "lblDesc1";
            this.lblDesc1.Size = new System.Drawing.Size(81, 13);
            this.lblDesc1.TabIndex = 12;
            this.lblDesc1.Text = "Desconto INSS";
            // 
            // lblDesc2
            // 
            this.lblDesc2.AutoSize = true;
            this.lblDesc2.Location = new System.Drawing.Point(422, 384);
            this.lblDesc2.Name = "lblDesc2";
            this.lblDesc2.Size = new System.Drawing.Size(80, 13);
            this.lblDesc2.TabIndex = 13;
            this.lblDesc2.Text = "Desconto IRPF";
            // 
            // txtbxDesc1
            // 
            this.txtbxDesc1.Location = new System.Drawing.Point(520, 340);
            this.txtbxDesc1.Name = "txtbxDesc1";
            this.txtbxDesc1.Size = new System.Drawing.Size(100, 20);
            this.txtbxDesc1.TabIndex = 14;
            // 
            // txtbxAliq1
            // 
            this.txtbxAliq1.Location = new System.Drawing.Point(182, 341);
            this.txtbxAliq1.Name = "txtbxAliq1";
            this.txtbxAliq1.Size = new System.Drawing.Size(100, 20);
            this.txtbxAliq1.TabIndex = 15;
            // 
            // txtbxDesc2
            // 
            this.txtbxDesc2.Location = new System.Drawing.Point(520, 381);
            this.txtbxDesc2.Name = "txtbxDesc2";
            this.txtbxDesc2.Size = new System.Drawing.Size(100, 20);
            this.txtbxDesc2.TabIndex = 16;
            // 
            // txtbxAliq2
            // 
            this.txtbxAliq2.Location = new System.Drawing.Point(182, 381);
            this.txtbxAliq2.Name = "txtbxAliq2";
            this.txtbxAliq2.Size = new System.Drawing.Size(100, 20);
            this.txtbxAliq2.TabIndex = 17;
            // 
            // txtbxSalFamilia
            // 
            this.txtbxSalFamilia.Location = new System.Drawing.Point(182, 420);
            this.txtbxSalFamilia.Name = "txtbxSalFamilia";
            this.txtbxSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtbxSalFamilia.TabIndex = 18;
            // 
            // txtbxSalLiq
            // 
            this.txtbxSalLiq.Location = new System.Drawing.Point(182, 456);
            this.txtbxSalLiq.Name = "txtbxSalLiq";
            this.txtbxSalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtbxSalLiq.TabIndex = 19;
            this.txtbxSalLiq.Text = "\r\n";
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(322, 256);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(132, 23);
            this.btnVerifica.TabIndex = 6;
            this.btnVerifica.Text = "Verifica desconto";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // NumUpFilhos
            // 
            this.NumUpFilhos.Location = new System.Drawing.Point(203, 206);
            this.NumUpFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NumUpFilhos.Name = "NumUpFilhos";
            this.NumUpFilhos.Size = new System.Drawing.Size(42, 20);
            this.NumUpFilhos.TabIndex = 21;
            this.NumUpFilhos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumUpFilhos_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 531);
            this.Controls.Add(this.NumUpFilhos);
            this.Controls.Add(this.txtbxSalLiq);
            this.Controls.Add(this.txtbxSalFamilia);
            this.Controls.Add(this.txtbxAliq2);
            this.Controls.Add(this.txtbxDesc2);
            this.Controls.Add(this.txtbxAliq1);
            this.Controls.Add(this.txtbxDesc1);
            this.Controls.Add(this.lblDesc2);
            this.Controls.Add(this.lblDesc1);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliq2);
            this.Controls.Add(this.lblAliq1);
            this.Controls.Add(this.mskdbxSalBruto);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.txtbxNome);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NumUpFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.TextBox txtbxNome;
        private System.Windows.Forms.MaskedTextBox mskdbxSalBruto;
        private System.Windows.Forms.Label lblAliq1;
        private System.Windows.Forms.Label lblAliq2;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDesc1;
        private System.Windows.Forms.Label lblDesc2;
        private System.Windows.Forms.TextBox txtbxDesc1;
        private System.Windows.Forms.TextBox txtbxAliq1;
        private System.Windows.Forms.TextBox txtbxDesc2;
        private System.Windows.Forms.TextBox txtbxAliq2;
        private System.Windows.Forms.TextBox txtbxSalFamilia;
        private System.Windows.Forms.TextBox txtbxSalLiq;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.NumericUpDown NumUpFilhos;
    }
}


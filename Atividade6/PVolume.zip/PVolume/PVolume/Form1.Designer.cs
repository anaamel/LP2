﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRaio = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.txtbxRaio = new System.Windows.Forms.TextBox();
            this.txtbxAltura = new System.Windows.Forms.TextBox();
            this.txtbxVolume = new System.Windows.Forms.TextBox();
            this.btnCalculo = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRaio
            // 
            this.lblRaio.AutoSize = true;
            this.lblRaio.Location = new System.Drawing.Point(91, 57);
            this.lblRaio.Name = "lblRaio";
            this.lblRaio.Size = new System.Drawing.Size(29, 13);
            this.lblRaio.TabIndex = 0;
            this.lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(91, 115);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(34, 13);
            this.lblAltura.TabIndex = 1;
            this.lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Location = new System.Drawing.Point(91, 165);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(42, 13);
            this.lblVolume.TabIndex = 2;
            this.lblVolume.Text = "Volume";
            // 
            // txtbxRaio
            // 
            this.txtbxRaio.Location = new System.Drawing.Point(193, 57);
            this.txtbxRaio.Name = "txtbxRaio";
            this.txtbxRaio.Size = new System.Drawing.Size(100, 20);
            this.txtbxRaio.TabIndex = 3;
            this.txtbxRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxRaio_KeyPress);
            this.txtbxRaio.Validated += new System.EventHandler(this.TxtbxRaio_Validated);
            // 
            // txtbxAltura
            // 
            this.txtbxAltura.Location = new System.Drawing.Point(193, 108);
            this.txtbxAltura.Name = "txtbxAltura";
            this.txtbxAltura.Size = new System.Drawing.Size(100, 20);
            this.txtbxAltura.TabIndex = 4;
            this.txtbxAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxAltura_KeyPress);
            this.txtbxAltura.Validated += new System.EventHandler(this.TxtbxAltura_Validated);
            // 
            // txtbxVolume
            // 
            this.txtbxVolume.Location = new System.Drawing.Point(193, 158);
            this.txtbxVolume.Name = "txtbxVolume";
            this.txtbxVolume.Size = new System.Drawing.Size(100, 20);
            this.txtbxVolume.TabIndex = 5;
            // 
            // btnCalculo
            // 
            this.btnCalculo.Location = new System.Drawing.Point(111, 227);
            this.btnCalculo.Name = "btnCalculo";
            this.btnCalculo.Size = new System.Drawing.Size(75, 23);
            this.btnCalculo.TabIndex = 6;
            this.btnCalculo.Text = "Calcular";
            this.btnCalculo.UseVisualStyleBackColor = true;
            this.btnCalculo.Click += new System.EventHandler(this.BtnCalculo_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(266, 227);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(75, 23);
            this.btnFechar.TabIndex = 7;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnCalculo);
            this.Controls.Add(this.txtbxVolume);
            this.Controls.Add(this.txtbxAltura);
            this.Controls.Add(this.txtbxRaio);
            this.Controls.Add(this.lblVolume);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblRaio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRaio;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.TextBox txtbxRaio;
        private System.Windows.Forms.TextBox txtbxAltura;
        private System.Windows.Forms.TextBox txtbxVolume;
        private System.Windows.Forms.Button btnCalculo;
        private System.Windows.Forms.Button btnFechar;
    }
}


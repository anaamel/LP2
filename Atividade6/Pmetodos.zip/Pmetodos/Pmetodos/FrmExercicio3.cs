﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemov_Click(object sender, EventArgs e)
        {
            int posicao = txtbxPalavra2.Text.IndexOf(txtbxPalavra1.Text);
            //a        ss      t 
            //casa assessoria Fatec
            //posicao
            //1       1        2
            //csa   aessoria    Faec

            while (posicao >=0 )
            {
                txtbxPalavra2.Text = txtbxPalavra2.Text.Substring(0,
                    posicao) +
                    txtbxPalavra2.Text.Substring(posicao +
                    txtbxPalavra1.Text.Length,
                    txtbxPalavra2.Text.Length - posicao -
                    txtbxPalavra1.Text.Length);

                posicao = txtbxPalavra2.Text.IndexOf(txtbxPalavra1.Text);
            }
        }
    }
}

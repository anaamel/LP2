﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CopiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Escolheu Copiar");
        }

        private void ColarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Escolheu Colar");
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                //da erro se forms não tem nada
                Application.OpenForms["frmExercicio2"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                FrmExercicio2 Frm2 = new FrmExercicio2();
                Frm2.MdiParent = this;
                Frm2.WindowState = FormWindowState.Maximized;
                Frm2.Show();
            }
        }

        private void Exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                //da erro se forms não tem nada
                Application.OpenForms["frmExercicio3"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                FrmExercicio3 Frm3 = new FrmExercicio3();
                Frm3.MdiParent = this;
                Frm3.WindowState = FormWindowState.Maximized;
                Frm3.Show();
            }
        }

        private void Exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                //da erro se forms não tem nada
                Application.OpenForms["frmExercicio4"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio4"].Activate();
            }
            else
            {
                FrmExercicio4 Frm4 = new FrmExercicio4();
                Frm4.MdiParent = this;
                Frm4.WindowState = FormWindowState.Maximized;
                Frm4.Show();
            }
        }

        private void Exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                //da erro se forms não tem nada
                Application.OpenForms["frmExercicio5"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio5"].Activate();
            }
            else
            {
                FrmExercicio5 Frm5 = new FrmExercicio5();
                Frm5.MdiParent = this;
                Frm5.WindowState = FormWindowState.Maximized;
                Frm5.Show();
            }
        }
    }
    }
    }
}

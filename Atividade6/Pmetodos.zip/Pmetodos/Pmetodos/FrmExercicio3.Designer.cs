﻿namespace Pmetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInsAst = new System.Windows.Forms.Button();
            this.btnIns = new System.Windows.Forms.Button();
            this.btnRemov = new System.Windows.Forms.Button();
            this.txtbxPalavra2 = new System.Windows.Forms.TextBox();
            this.txtbxPalavra1 = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInsAst
            // 
            this.btnInsAst.Location = new System.Drawing.Point(539, 292);
            this.btnInsAst.Name = "btnInsAst";
            this.btnInsAst.Size = new System.Drawing.Size(103, 57);
            this.btnInsAst.TabIndex = 13;
            this.btnInsAst.Text = "Inserir asteriscos meio 1º";
            this.btnInsAst.UseVisualStyleBackColor = true;
            // 
            // btnIns
            // 
            this.btnIns.Location = new System.Drawing.Point(351, 293);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(109, 56);
            this.btnIns.TabIndex = 12;
            this.btnIns.Text = "Insere 1º meio 2º";
            this.btnIns.UseVisualStyleBackColor = true;
            // 
            // btnRemov
            // 
            this.btnRemov.Location = new System.Drawing.Point(165, 293);
            this.btnRemov.Name = "btnRemov";
            this.btnRemov.Size = new System.Drawing.Size(109, 56);
            this.btnRemov.TabIndex = 11;
            this.btnRemov.Text = "Remover";
            this.btnRemov.UseVisualStyleBackColor = true;
            this.btnRemov.Click += new System.EventHandler(this.BtnRemov_Click);
            // 
            // txtbxPalavra2
            // 
            this.txtbxPalavra2.Location = new System.Drawing.Point(272, 172);
            this.txtbxPalavra2.Name = "txtbxPalavra2";
            this.txtbxPalavra2.Size = new System.Drawing.Size(253, 20);
            this.txtbxPalavra2.TabIndex = 10;
            // 
            // txtbxPalavra1
            // 
            this.txtbxPalavra1.Location = new System.Drawing.Point(272, 102);
            this.txtbxPalavra1.Name = "txtbxPalavra1";
            this.txtbxPalavra1.Size = new System.Drawing.Size(253, 20);
            this.txtbxPalavra1.TabIndex = 9;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(162, 180);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 8;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(159, 110);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 7;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInsAst);
            this.Controls.Add(this.btnIns);
            this.Controls.Add(this.btnRemov);
            this.Controls.Add(this.txtbxPalavra2);
            this.Controls.Add(this.txtbxPalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInsAst;
        private System.Windows.Forms.Button btnIns;
        private System.Windows.Forms.Button btnRemov;
        private System.Windows.Forms.TextBox txtbxPalavra2;
        private System.Windows.Forms.TextBox txtbxPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
    }
}
﻿namespace Pmetodos
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtbxPalavra1 = new System.Windows.Forms.TextBox();
            this.txtbxPalavra2 = new System.Windows.Forms.TextBox();
            this.btnComp = new System.Windows.Forms.Button();
            this.btnIns = new System.Windows.Forms.Button();
            this.btnInsAst = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(137, 60);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(140, 130);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // txtbxPalavra1
            // 
            this.txtbxPalavra1.Location = new System.Drawing.Point(250, 52);
            this.txtbxPalavra1.Name = "txtbxPalavra1";
            this.txtbxPalavra1.Size = new System.Drawing.Size(253, 20);
            this.txtbxPalavra1.TabIndex = 2;
            // 
            // txtbxPalavra2
            // 
            this.txtbxPalavra2.Location = new System.Drawing.Point(250, 122);
            this.txtbxPalavra2.Name = "txtbxPalavra2";
            this.txtbxPalavra2.Size = new System.Drawing.Size(253, 20);
            this.txtbxPalavra2.TabIndex = 3;
            // 
            // btnComp
            // 
            this.btnComp.Location = new System.Drawing.Point(143, 243);
            this.btnComp.Name = "btnComp";
            this.btnComp.Size = new System.Drawing.Size(109, 56);
            this.btnComp.TabIndex = 4;
            this.btnComp.Text = "Comparar iguais";
            this.btnComp.UseVisualStyleBackColor = true;
            this.btnComp.Click += new System.EventHandler(this.BtnComp_Click);
            // 
            // btnIns
            // 
            this.btnIns.Location = new System.Drawing.Point(329, 243);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(109, 56);
            this.btnIns.TabIndex = 5;
            this.btnIns.Text = "Insere 1º meio 2º";
            this.btnIns.UseVisualStyleBackColor = true;
            this.btnIns.Click += new System.EventHandler(this.BtnIns_Click);
            // 
            // btnInsAst
            // 
            this.btnInsAst.Location = new System.Drawing.Point(517, 242);
            this.btnInsAst.Name = "btnInsAst";
            this.btnInsAst.Size = new System.Drawing.Size(103, 57);
            this.btnInsAst.TabIndex = 6;
            this.btnInsAst.Text = "Inserir asteriscos meio 1º";
            this.btnInsAst.UseVisualStyleBackColor = true;
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInsAst);
            this.Controls.Add(this.btnIns);
            this.Controls.Add(this.btnComp);
            this.Controls.Add(this.txtbxPalavra2);
            this.Controls.Add(this.txtbxPalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtbxPalavra1;
        private System.Windows.Forms.TextBox txtbxPalavra2;
        private System.Windows.Forms.Button btnComp;
        private System.Windows.Forms.Button btnIns;
        private System.Windows.Forms.Button btnInsAst;
    }
}
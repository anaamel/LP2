﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnComp_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtbxPalavra1.Text, txtbxPalavra2, true)
                ==0)
        }

        private void BtnIns_Click(object sender, EventArgs e)
        {
            int metade = txtbxPalavra2.Text.Length / 2;
            //a      a       a
            //casa Fatec Assessoria
            //ca    Fa     Asses
            //caa   Faa   Assesa
            txtPalavra2.Text = txtbxPalavra2.Text.Substring(0, metade)+
                txtbxPalavra1.Text +
                txtbxPalavra2.Text.Substring(metade+1,
                txtbxPalavra2.Text.Length-metade)
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;


        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {

            if (Double.TryParse(txtbxAlt.Text, out altura) &&
                    Double.TryParse(txtbxPeso.Text, out peso))
            {
                if ((altura <= 0) || (peso <= 0))
                MessageBox.Show("Valores devem ser maiores que zero");
                    else
                    {
                        imc = peso / (Math.Pow(altura, 2));

                        imc = Math.Round(imc, 1);

                        imc.ToString("N1");

                        if (imc <= 18.5)
                            MessageBox.Show("Magreza");
                        else if (imc <= 24.9)
                            MessageBox.Show("Normal");
                        else if (imc <= 29.9)
                            MessageBox.Show("Sobrepeso");
                        else if (imc <= 39.9)
                            MessageBox.Show("Obesidade");
                        else
                            MessageBox.Show("Obesidade Grave");
                    }
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtbxAlt.Clear();
            txtbxPeso.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }



        private void txtbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxPeso.Text, out peso))
                MessageBox.Show("Peso Inválido");
            else if (peso <= 0)
                MessageBox.Show("O Peso deve ser maior que zero.");
        }

        private void txtbxAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxAlt.Text, out altura))
                MessageBox.Show("Altura Inválida");
            else if (altura <= 0)
                MessageBox.Show("A altura deve ser maior que zero.");
        }

        private void txtbxPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (e.KeyChar == (char)(13))
                {
                    SendKeys.Send("{TAB}");
                    e.Handled = true;
                }
            }
        }

    }
}

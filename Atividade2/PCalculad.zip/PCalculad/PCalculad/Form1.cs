﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculad
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtbxNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum1.Text, out numero1))
                MessageBox.Show("Primeiro valor inválido");
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtbxNum1.Clear();
            txtbxNum2.Clear();
            txtbxResul.Clear();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum1.Text, out numero1))
            {
                MessageBox.Show("Primeiro valor inválido");
                txtbxNum1.Focus();
            }
            if (!double.TryParse(txtbxNum2.Text, out numero2))
            {
                MessageBox.Show("Segundo valor inválido");
                txtbxNum2.Focus();
            }
            resultado = numero1 + numero2;
            txtbxResul.Text = resultado.ToString("N2");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum1.Text, out numero1))
            {
                MessageBox.Show("Primeiro valor inválido");
                txtbxNum1.Focus();
            }
            if (!double.TryParse(txtbxNum2.Text, out numero2))
            {
                MessageBox.Show("Segundo valor inválido");
                txtbxNum2.Focus();
            }
            resultado = numero1 - numero2;
            txtbxResul.Text = resultado.ToString("N2");
        }

        private void btnMultp_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum1.Text, out numero1))
            {
                MessageBox.Show("Primeiro valor inválido");
                txtbxNum1.Focus();
            }
            if (!double.TryParse(txtbxNum2.Text, out numero2))
            {
                MessageBox.Show("Segundo valor inválido");
                txtbxNum2.Focus();
            }
            resultado = numero1 * numero2;
            txtbxResul.Text = resultado.ToString("N2");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum1.Text, out numero1))
            {
                MessageBox.Show("Primeiro valor Inválido");
                txtbxNum1.Focus();
            }
            if (!double.TryParse(txtbxNum2.Text, out numero2))
            {
                MessageBox.Show("Segundo valor Inválido");
                txtbxNum2.Focus();
            }
            if (numero2 == 0)
            {
                MessageBox.Show("Impossivel dividir por zero");
                txtbxNum2.Focus();
            }
            resultado = numero1 / numero2;
            txtbxResul.Text = resultado.ToString("N2");
        }

        private void txtbxNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxNum2.Text, out numero2))
                MessageBox.Show("Segundo valor inválido");
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
